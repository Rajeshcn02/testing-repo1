﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using TCatSysManagerLib;

namespace AI_BuildExample
{
    class Program
    {
        private static String path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + @"\TwinCAT Projekt1\TwinCAT Projekt1.sln";
        [STAThread]
        static void Main(string[] args)
        {
            // create TcXaeShell instance
            Type type = System.Type.GetTypeFromProgID("TcXaeShell.DTE.15.0");
            EnvDTE.DTE dte = (EnvDTE.DTE)System.Activator.CreateInstance(type);
            dte.SuppressUI = false;
            dte.MainWindow.Visible = true;
            // register message filter, protection against RPC_E_CALL_REJECTED exception
            MessageFilter.Register();

            // open solution
            EnvDTE.Solution solution = dte.Solution;
            solution.Open(path);
            // get the first project in the solution
            EnvDTE.Project prj = solution.Projects.Item(1);
            // get the system manager object, with this you can navigate through the project structure
            ITcSysManager systemManager = (ITcSysManager)prj.Object;
            // got to references folder from plc project or library project
            ITcSmTreeItem references = systemManager.LookupTreeItem("TIPC^PLC^PLC Projekt^References");
            ITcPlcLibraryManager libManager = (ITcPlcLibraryManager)references;
            // add a library with the newest version
            libManager.AddLibrary("Tc2_MC2", "*", "Beckhoff Automation GmbH");

            // add settings to the plc project and set version number
            ITcSmTreeItem libraryTreeItem = (ITcSmTreeItem)systemManager.LookupTreeItem("TIPC^PLC^PLC Projekt");
            setProjectProperties(libraryTreeItem, "AutomationInterface", "Generated", "1.0");

            // build project ans save solution
            solution.SolutionBuild.Build(false);
            prj.Save();
            solution.SaveAs(path);

            //revoke message filter
            MessageFilter.Revoke();

            Console.WriteLine("Finish");
            Console.ReadKey();
        }

        private static void setProjectProperties(ITcSmTreeItem item, string companyName, string title, string Version)
        {
            XmlDocument xml = new XmlDocument();
            xml.LoadXml(item.ProduceXml());
            XmlNode node = xml.SelectSingleNode("/TreeItem/IECProjectDef/ProjectInfo/Company");
            node.InnerText = companyName;
            node = xml.SelectSingleNode("/TreeItem/IECProjectDef/ProjectInfo/Title");
            node.InnerText = title;
            node = xml.SelectSingleNode("/TreeItem/IECProjectDef/ProjectInfo/Version");
            node.InnerText = Version;
            item.ConsumeXml(xml.OuterXml);
        }

    }
}
