﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using TCatSysManagerLib;

namespace AI_Library
{
    class Program
    {
        private static String path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + @"\Test\Solution1";
        [STAThread]
        static void Main(string[] args)
        {
            // Create VS instance
            WriteLine("Create VS instance");
            Type type = System.Type.GetTypeFromProgID("TcXaeShell.DTE.15.0");
            EnvDTE.DTE dte = (EnvDTE.DTE)System.Activator.CreateInstance(type);
            dte.SuppressUI = false;
            dte.MainWindow.Visible = true;
            MessageFilter.Register();

            // Create Directory for Solution
            WriteLine("Create Directory for Solution");
            FileHelper.DeleteDirectory(path);
            Directory.CreateDirectory(path);

            // Create Solution
            WriteLine("Create Solution");
            EnvDTE.Solution solution = dte.Solution;
            solution.Create(path, "Solution1");
            solution.SaveAs(path + "\\Solution1.sln");

            // Create TwinCAT3 ProjectUI
            WriteLine("Create TwinCAT3 Project");
            string template = @"C:\TwinCAT\3.1\Components\Base\PrjTemplate\TwinCAT Project.tsproj";
            EnvDTE.Project project = solution.AddFromTemplate(template, path, "TCProject");

            // Create System Manager object
            WriteLine("Create System Manager object");
            ITcSysManager3 sysManager = project.Object;

            WriteLine("Create PLC Project");
            ITcSmTreeItem plcConfig = sysManager.LookupTreeItem("TIPC");
            ITcSmTreeItem plcProject = plcConfig.CreateChild("GeneratedPLC", 0, "", "Standard PLC Template.plcproj");

            //Create POU
            WriteLine("Create POU");
            ITcSmTreeItem plcPouFolder = sysManager.LookupTreeItem("TIPC^GeneratedPLC^GeneratedPLCProjekt^POUs");
            ITcSmTreeItem fb = plcPouFolder.CreateChild("FB_Blinker", 604, "", IECLANGUAGETYPES.IECLANGUAGE_ST);
            ITcPlcPou pou = (ITcPlcPou)fb;

            // Write Template into new POU
            WriteLine("Write Template into new POU");
            String temp = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), @"Templates\FB_Blinker.xml");
            XmlDocument doc = new XmlDocument();
            doc.Load(temp);
            pou.DocumentXml = doc.OuterXml;

            // Write call from new Programm into Main Programm and create Variabels in Declaration
            WriteLine("Write call from new Programm into Main Programm and create Variabels in Declaration");
            ITcSmTreeItem mainProgram = sysManager.LookupTreeItem("TIPC^GeneratedPLC^GeneratedPLCProjekt^POUs^MAIN");
            ITcPlcPou main = (ITcPlcPou)mainProgram;
            ITcPlcDeclaration dec = (ITcPlcDeclaration)main;
            dec.DeclarationText = "PROGRAM MAIN\r\n" +
                                    "VAR\r\n" +
                                        "\tfbBlinker: FB_Blinker;\r\n" +
                                        "\tbSchalter1 AT %I*: BOOL;\r\n" +
                                        "\tbLampe1 AT %Q*: BOOL;\r\n" +
                                    "END_VAR";
            ITcPlcImplementation imp = (ITcPlcImplementation)main;
            imp.ImplementationText = "fbBlinker(bEnable:= TRUE, tOnTime:= T#100ms, tOffTime:= T#100ms, Q=> bLampe1);";

            // Save Project and Solution
            WriteLine("Save Project and Solution");
            project.Save();
            solution.SaveAs(path + "\\Solution1.sln");

            // Set comapny name, title and version
            WriteLine("Set comapny name, title and version");
            ITcSmTreeItem libraryTreeItem = (ITcSmTreeItem)sysManager.LookupTreeItem("TIPC^GeneratedPLC^GeneratedPLCProjekt");
            setProjectProperties(libraryTreeItem, "AutomationInterface", "GeneratedLibrary", "1.0");

            // Save as library an install
            WriteLine("Save as library an install");
            ITcPlcIECProject libraryProject = (ITcPlcIECProject) sysManager.LookupTreeItem("TIPC^GeneratedPLC^GeneratedPLCProjekt");
            libraryProject.SaveAsLibrary(Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), @"Generated.library"), true);

            MessageFilter.Revoke();
            Console.ReadKey();
        }

        private static void WriteLine(string text)
        {
            Console.WriteLine(text);
        }

        private static void setProjectProperties(ITcSmTreeItem item, string companyName, string title, string Version)
        {
            XmlDocument xml = new XmlDocument();
            xml.LoadXml(item.ProduceXml());
            XmlNode node = xml.SelectSingleNode("/TreeItem/IECProjectDef/ProjectInfo/Company");
            node.InnerText = companyName;
            node = xml.SelectSingleNode("/TreeItem/IECProjectDef/ProjectInfo/Title");
            node.InnerText = title;
            node = xml.SelectSingleNode("/TreeItem/IECProjectDef/ProjectInfo/Version");
            node.InnerText = Version;
            item.ConsumeXml(xml.OuterXml);
        }
    }
}
